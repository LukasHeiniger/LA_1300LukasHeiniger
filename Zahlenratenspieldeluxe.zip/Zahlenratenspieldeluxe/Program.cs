﻿

using System;
using System.ComponentModel;
using System.IO;
using System.Security;
using System.Threading;

namespace Zahlenratespiel
{


    class Ratespiel
    {
        //Zahlsp = Zahl des Spieler
        static void Main(string[] args)
        {
            
            int guess = 0;
            int attempts = 0;
            string name = "";
            int savedeci = 0;

            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;

         

            Console.WriteLine("Wilkommmen beim Zahleratespiel");
            space();

            Game:
            attempts = 0;

            Console.Write("Gib deinen Namen ein: ");
            name = Convert.ToString(Console.ReadLine());

            Console.WriteLine("Wenn du das Spiel bereits kennst drücke 1 falls nicht drücke 2 um eine Erklärung des Spiel's zubekommen");
            int deci = Convert.ToInt32(Console.ReadLine());

            if (deci == 2)
            {

                Console.WriteLine("Regeln: Das Spiel kurz erklärt. Um zugewinnen musst du die generierte Zahl erraten. Desto weniger verüsche du gebraucht hast umso besser warst du");
                

            }

            Console.Write("Wähle deine schwierigkeit 0 - X definiere X um deine Schwierigkeit festzulegen.");
            int lvl = Convert.ToInt32(Console.ReadLine());
            int lvl1 = lvl + 1;

            Random number = new Random();
            int randnumber = number.Next(0, lvl1);

            do
            {
                try
                {
                    space();
                    Console.Write(name + " rate die Zufallszahl zwische 1 und " +lvl );
                    guess = Convert.ToInt32(Console.ReadLine());
                    Console.Beep(400, 100);

                }
                catch (FormatException)
                {
                    space();
                    Console.WriteLine("Bitte gib eine Zahl ein");
                    space(); ;
                }  
                
                

                if(guess < randnumber)
                {
                    Console.WriteLine("Die Zahl ist grösser als deine geratene Zahl");
                }

                if (guess > randnumber)
                {
                    Console.WriteLine("Die Zahl ist kleiner als deine geratene Zahl");
                }

                attempts++;

            } while(guess != randnumber);
            
            space();

            if(attempts < 5)
            {
                Console.WriteLine("Bravo!! Du hast es geschaft sie haben nur " + attempts + " Versuche gebraucht");
                Console.Beep(600, 100);
            }
            else
            {
                Console.WriteLine("Das geht besser du hast " + attempts + " Versuche gebraucht");
                Console.Beep(200, 100);
            }

            Console.Write("Möchtest du die Daten in ein Dokumentspeichern? (JA/1)(NEIN/2): ");
            savedeci = Convert.ToInt32(Console.ReadLine());

            if(savedeci == 1)
            {
                // Code Teilweise von ChatGpt muss in Doku Dokummentiert werden.


                string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string documentContent = name + " hat " + attempts+ " versuche gebraucht.";
                string documentName = "ScoreList";

                if (!File.Exists(path))
                {
                    Console.WriteLine("Das Textdokument " + documentName + "wurde auf dem Desktop erstellt.");
                }
                else
                {
                    Console.WriteLine("Die Daten wurden erfolgreich gespeichert");
                }


                string fullPath = Path.Combine(path, documentName);

                File.AppendAllText(fullPath, Environment.NewLine + documentContent);
                
                // ende Chatgpt code. Code wurde nicht 1 zu 1 übernommen trz. keine eigenleistung wurde in Projektdoku vermerkt.


                goto Game;   
            }
            else
            {
              goto Game;
            }
            

            void space()
            {
                Console.WriteLine();
            }
            

        }
    }
}












































